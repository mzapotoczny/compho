#include"common.h"
#include<vector>

std::vector<int> get_gradient(rgbImage& inputImage);

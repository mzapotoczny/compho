#include"common.h"

void apply_gamma(rgbImage& source, float gamma);
